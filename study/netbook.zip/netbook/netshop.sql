/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50027
Source Host           : localhost:3306
Source Database       : netshop

Target Server Type    : MYSQL
Target Server Version : 50027
File Encoding         : 65001

Date: 2014-06-27 22:04:47
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `book`
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `bid` int(11) NOT NULL auto_increment,
  `isbn` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL,
  `title` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `author` varchar(45) character set utf8 collate utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY  (`bid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('1', '111111113333333333', '01_Java 应用程序设计', 'AA', '45.6');
INSERT INTO `book` VALUES ('2', 'AAAAAAAA222222222', '02_Android 应用程序设计', 'BB', '34.6');
INSERT INTO `book` VALUES ('3', '333333333333333333', '03_Java EE 轻量级框架', 'CC', '56.8');
INSERT INTO `book` VALUES ('4', 'CCCCCCCC444444444', '04_算法导轮', 'XL', '12.4');
INSERT INTO `book` VALUES ('5', 'FFFFFFFSSSSSSSWW', '05_Linux 底层源码分析', 'DD', '34.7');

-- ----------------------------
-- Table structure for `order`
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `oid` int(11) NOT NULL auto_increment,
  `userId` int(11) NOT NULL,
  `zipcode` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL,
  `phone` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `address` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `total` double NOT NULL,
  PRIMARY KEY  (`oid`),
  KEY `FK651874EEE8ED743` (`userId`),
  CONSTRAINT `FK651874EEE8ED743` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES ('1', '2', '2345', '23423', '23452', '45.6');
INSERT INTO `order` VALUES ('2', '2', '3423', '2341', '234123', '45.6');
INSERT INTO `order` VALUES ('3', '2', 'wert', 'etw', 'wertw', '34.7');
INSERT INTO `order` VALUES ('4', '2', 'sdfg', 'sdgfsd', 'sdfg', '56.8');
INSERT INTO `order` VALUES ('5', '2', '1341', '121234', '男同', '34.7');
INSERT INTO `order` VALUES ('6', '2', '226015', '10110', '????', '45.6');
INSERT INTO `order` VALUES ('7', '2', '', '??', '', '45.6');
INSERT INTO `order` VALUES ('8', '2', '', ' ??v?', '', '102.4');
INSERT INTO `order` VALUES ('9', '2', '??', '??', '??', '45.6');
INSERT INTO `order` VALUES ('10', '2', '', '', '', '45.6');
INSERT INTO `order` VALUES ('11', '2', '测试', '测试', '测试', '45.6');

-- ----------------------------
-- Table structure for `orderitem`
-- ----------------------------
DROP TABLE IF EXISTS `orderitem`;
CREATE TABLE `orderitem` (
  `itemId` int(11) NOT NULL auto_increment,
  `oid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY  (`itemId`),
  KEY `FKE8B2AB61205C7138` (`bid`),
  KEY `FKE8B2AB61EBBDA606` (`oid`),
  CONSTRAINT `FKE8B2AB61205C7138` FOREIGN KEY (`bid`) REFERENCES `book` (`bid`),
  CONSTRAINT `FKE8B2AB61EBBDA606` FOREIGN KEY (`oid`) REFERENCES `order` (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderitem
-- ----------------------------
INSERT INTO `orderitem` VALUES ('1', '1', '1', '1');
INSERT INTO `orderitem` VALUES ('2', '2', '1', '1');
INSERT INTO `orderitem` VALUES ('3', '3', '5', '1');
INSERT INTO `orderitem` VALUES ('4', '4', '3', '1');
INSERT INTO `orderitem` VALUES ('5', '5', '5', '1');
INSERT INTO `orderitem` VALUES ('6', '6', '1', '1');
INSERT INTO `orderitem` VALUES ('7', '7', '1', '1');
INSERT INTO `orderitem` VALUES ('8', '8', '3', '1');
INSERT INTO `orderitem` VALUES ('9', '8', '1', '1');
INSERT INTO `orderitem` VALUES ('10', '9', '1', '1');
INSERT INTO `orderitem` VALUES ('11', '10', '1', '1');
INSERT INTO `orderitem` VALUES ('12', '11', '1', '1');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL auto_increment,
  `username` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  `password` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'root', '123456');
INSERT INTO `user` VALUES ('2', 'test', 'test');
