package com.xl.model;

import java.util.HashSet;
import java.util.Set;


public class Order {


	private Integer oid;
	private User user;
	private String zipcode;
	private String phone;
	private String address;
	private Double total;
	private Set orderitems = new HashSet(0);


	public Order() {
	}

	public Order(User user, String zipcode, String phone,
			String address, Double total) {
		this.user = user;
		this.zipcode = zipcode;
		this.phone = phone;
		this.address = address;
		this.total = total;
	}

	public Order(User user, String zipcode, String phone,
			String address, Double total, Set orderitems) {
		this.user = user;
		this.zipcode = zipcode;
		this.phone = phone;
		this.address = address;
		this.total = total;
		this.orderitems = orderitems;
	}

	public Integer getOid() {
		return this.oid;
	}

	public void setOid(Integer oid) {
		this.oid = oid;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getZipcode() {
		return this.zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getTotal() {
		return this.total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	public Set getOrderitems() {
		return this.orderitems;
	}

	public void setOrderitems(Set orderitems) {
		this.orderitems = orderitems;
	}

}