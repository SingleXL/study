package com.xl.model;


public class Orderitem implements java.io.Serializable {

	private Integer itemId;
	private Order order;
	private Book books;
	private Integer quantity;

	public Orderitem() {
	}

	public Orderitem(Order order, Book books, Integer quantity) {
		this.order = order;
		this.books = books;
		this.quantity = quantity;
	}

	public Integer getItemId() {
		return this.itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Order getOrder() {
		return this.order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Book getBooks() {
		return this.books;
	}

	public void setBooks(Book books) {
		this.books = books;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}