package com.xl.action;

import java.util.*;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.util.ValueStack;
import com.xl.dao.BookDao;
import com.xl.model.Book;

public class BooksAction extends ActionSupport {
	private Book book;
	private List list;
	private Integer bid;
	private Map cart;

	public Map getCart() {
		return cart;
	}

	public void setCart(Map cart) {
		this.cart = cart;
	}

	public Integer getBid() {
		return bid;
	}

	public void setBid(Integer bid) {
		this.bid = bid;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public String addBook() {
		BookDao dao = new BookDao();
		if (dao.add(getBook()) == 1)
			return SUCCESS;
		else
			return ERROR;
	}

	public String listBooks() {
		BookDao dao = new BookDao();
		list = dao.listBooks();
		return SUCCESS;
	}

	public String viewDetails() {
		BookDao dao = new BookDao();
		book = dao.searchById(bid);
		
//		ValueStack valueStack = ActionContext.getContext().getValueStack();
//		valueStack.push(books);
		return SUCCESS;
	}

	public String balance() {
		BookDao dao = new BookDao();
		book = dao.searchById(bid);
		return SUCCESS;
	}

	public String addCart() {
		Map<String, Object> session = ActionContext.getContext().getSession();
		cart = (Map) session.get("cart");
		
		if (cart == null) {
			cart = new HashMap();
			session.put("cart", cart);
		}
		
		CartItem cartItem = (CartItem) cart.get(book.getIsbn());
		
		
		if (cartItem != null) {
			cartItem.setQuantity(cartItem.getQuantity() + 1);
			cartItem.setTotal(cartItem.getQuantity() * book.getPrice());
		} else {
			CartItem cartItem1 = new CartItem();
			cartItem1.setBooks(book);
			cartItem1.setQuantity(1);
			cartItem1.setTotal(cartItem1.getQuantity() * book.getPrice());
			cart.put(book.getIsbn(), cartItem1);
			session.put("cart", cart);
		}

		return "success";
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
}
