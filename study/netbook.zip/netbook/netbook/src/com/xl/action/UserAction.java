package com.xl.action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.xl.dao.UserDao;
import com.xl.model.User;

public class UserAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private String username;
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String addUser() throws Exception {

		User user = new User();
		user.setUsername(getUsername());
		user.setPassword(getPassword());

		UserDao dao = new UserDao();
		int result = dao.add(user);
		if (result == 1)
			return SUCCESS;
		else
			return INPUT;
	}

	public String login() throws Exception {

		Map<String, Object> session = ActionContext.getContext().getSession();

		User user = new User();
		user.setUsername(getUsername());
		user.setPassword(getPassword());

		UserDao dao = new UserDao();

		if ((user = dao.search(user)) != null) {
			session.put("user", user);
			return SUCCESS;
		} else
			return INPUT;
	}
}
