package com.xl.action;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.xl.dao.HibernateSessionFactory;
import com.xl.dao.OrderDao;
import com.xl.dao.OrderitemDao;
import com.xl.model.Order;
import com.xl.model.Orderitem;
import com.xl.model.User;

public class OrderAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private Order order;
	private double total;
	private Map cart;
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Map getCart() {
		return cart;
	}

	public void setCart(Map cart) {
		this.cart = cart;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public String balance() {
		Map<String, Object> session = ActionContext.getContext().getSession();
		cart = (Map) session.get("cart");
		user = (User) session.get("user");
		CartItem item;
		Set keys = cart.keySet();
		if (keys != null) {
			Iterator iterator = keys.iterator();
			while (iterator.hasNext()) {
				Object key = iterator.next();
				item = (CartItem) cart.get(key);
				total += item.getQuantity() * item.getBooks().getPrice();
			}
		}
		return SUCCESS;
	}

	public String addOrder() {
		Map<String, Object> session = ActionContext.getContext().getSession();
		cart = (Map) session.get("cart");
		user = (User) session.get("user");
		OrderDao orderDao = new OrderDao();
		OrderitemDao itemDao = new OrderitemDao();
		Orderitem orderitem;

		order.setUser(user);
		order.setTotal(getTotal());

		try {
			orderDao.add(order);
			CartItem item;
			Set keys = cart.keySet();
			if (keys != null) {
				Iterator iterator = keys.iterator();
				while (iterator.hasNext()) {
					Object key = iterator.next();
					item = (CartItem) cart.get(key);
					orderitem = new Orderitem();
					orderitem.setBooks(item.getBooks());
					orderitem.setOrder(order);
					orderitem.setQuantity(item.getQuantity());
					itemDao.add(orderitem);
				}
			}
			session.remove("cart");
			session.clear();
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}

	}
}