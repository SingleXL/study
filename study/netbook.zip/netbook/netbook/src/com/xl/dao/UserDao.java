package com.xl.dao;

import java.util.Iterator;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.xl.model.User;

public class UserDao {
	public User search(User user) {
		
		Session session = HibernateSessionFactory.getSession();
		String hql = "from User u where u.username=? and u.password=?";
		Query query = session.createQuery(hql);
		query.setString(0, user.getUsername());
		query.setString(1, user.getPassword());

		Iterator it = query.list().iterator();
		if (it.hasNext()) {
			user = (User) it.next();
		}
		return user;
	}

	public int add(User user) {
		int result = 0;
		Session s = HibernateSessionFactory.getSession();
		Transaction tx = s.beginTransaction();
		try {

			User usertemp = new User();
			usertemp.setUsername(user.getUsername());
			usertemp.setPassword(user.getPassword());
			s.save(usertemp);
			tx.commit();
			s.close();
			result = 1;
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
		return result;
	}

}
