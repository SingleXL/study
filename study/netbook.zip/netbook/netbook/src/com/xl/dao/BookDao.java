package com.xl.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.xl.model.Book;

public class BookDao {
	public Book searchById(Integer id) { 
		Book books;
		Session session = HibernateSessionFactory.getSession();
		books = (Book) session.get(Book.class, id);
		return books;
	}

	public int add(Book book) { 
		int result = 0;
		Session s = HibernateSessionFactory.getSession();
		Transaction tx = s.beginTransaction();
		try {
			Book books = new Book();
			books.setAuthor(book.getAuthor());
			books.setIsbn(book.getIsbn());
			books.setPrice(book.getPrice());
			books.setTitle(book.getTitle());
			s.save(book);
			tx.commit();
			s.close();
			result = 1;
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();

		}

		return result;
	}

	public List listBooks() {
		List list;
		Session s = HibernateSessionFactory.getSession();
		Transaction tx = s.beginTransaction();
		String hql = "from Book b ";
		Query query = s.createQuery(hql);
		list = query.list();
		return list;

	}

}
