package com.xl.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.xl.model.Order;

public class OrderDao {

	public int add(Order order) {
		int result = 0;
		Session s = HibernateSessionFactory.getSession();
		Transaction tx = s.beginTransaction();
		try {
			s.save(order);
			tx.commit();
			s.close();
			result = 1;
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();

		}

		return result;
	}

}
