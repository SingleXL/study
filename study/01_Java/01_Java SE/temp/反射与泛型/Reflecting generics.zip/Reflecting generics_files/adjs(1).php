var phpadsbanner = '';

phpadsbanner += '<'+'a href=\'http://www.artima.com/zcr/adclick.php?bannerid=517&amp;zoneid=2&amp;source=&amp;dest=http%3A%2F%2Fwww.escalatesoft.com%2F\' target=\'_blank\'><'+'img src=\'http://www.artima.com/azm/escalate-ad1-rec-call-us.jpg\' width=\'300\' height=\'250\' alt=\'Need Scala Training or Consulting? Call Escalate. http://www.escalatesoft.com/\' title=\'Need Scala Training or Consulting? Call Escalate. http://www.escalatesoft.com/\' border=\'0\'><'+'/a><'+'div id="beacon_517" style="position: absolute; left: 0px; top: 0px; visibility: hidden;"><'+'img src=\'http://www.artima.com/zcr/adlog.php?bannerid=517&amp;clientid=283&amp;zoneid=2&amp;source=&amp;block=0&amp;capping=0&amp;cb=8f4df212322a0155e9380d3cca6c0a26\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\'><'+'/div>';

document.write(phpadsbanner);
