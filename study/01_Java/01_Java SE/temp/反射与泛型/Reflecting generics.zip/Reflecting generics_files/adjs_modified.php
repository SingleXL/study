var phpadsbanner = '';

phpadsbanner += '<'+'a href=\'http://www.artima.com/zcr/adclick.php?bannerid=518&amp;zoneid=3&amp;source=&amp;dest=http%3A%2F%2Fwww.escalatesoft.com%2F\' target=\'_top\'><'+'img src=\'http://www.artima.com/azm/escalate-ad1-ss-call-us.jpg\' width=\'120\' height=\'600\' alt=\'Need Scala Training or Consulting? Call Escalate. http://www.escalatesoft.com/\' title=\'Need Scala Training or Consulting? Call Escalate. http://www.escalatesoft.com/\' border=\'0\'><'+'/a><'+'div id="beacon_518" style="position: absolute; left: 0px; top: 0px; visibility: hidden;"><'+'img src=\'http://www.artima.com/zcr/adlog.php?bannerid=518&amp;clientid=284&amp;zoneid=3&amp;source=&amp;block=0&amp;capping=0&amp;cb=8bacb6fc18ff2d7416908bff80818e24\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\'><'+'/div>';

if (document.phpAds_used) document.phpAds_used += 'bannerid:518,';

if (document.phpAds_used) document.phpAds_used += 'campaignid:284,';
