var phpadsbanner = '';

phpadsbanner += '<'+'a href=\'http://www.artima.com/zcr/adclick.php?bannerid=444&amp;zoneid=9&amp;source=&amp;dest=http%3A%2F%2Fwww.artima.com%2Fshop%2Feffective_cpp_in_an_embedded_environment\' target=\'_top\'>Effective C++ in an Embedded Environment - get the PDF eBook, only $24.95<'+'/a><'+'div id="beacon_444" style="position: absolute; left: 0px; top: 0px; visibility: hidden;"><'+'img src=\'http://www.artima.com/zcr/adlog.php?bannerid=444&amp;clientid=165&amp;zoneid=9&amp;source=&amp;block=0&amp;capping=0&amp;cb=d24daf03faf4fb26f3a7c89dc8024391\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\'><'+'/div>';

document.write(phpadsbanner);
