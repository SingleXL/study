﻿var ad_type = 'ms882';
var ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
/*document.writeln(ad_sc);

 ad_type = 'ms884_2';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);
*//*
 ad_type = 'ms875_3';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

 ad_type = 'ms864_4';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

 ad_type = 'ms846_5';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);
*/