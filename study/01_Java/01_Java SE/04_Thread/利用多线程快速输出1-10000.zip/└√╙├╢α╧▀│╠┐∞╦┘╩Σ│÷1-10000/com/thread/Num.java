package com.thread;

class Num {
	public boolean flag = false;
	public int num = 0;
}
