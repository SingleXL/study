package com.thread;

class Cout extends Thread {

	private Num num = null;

	public Cout(Num num) {
		this.num = num;
	}

	@Override
	public void run() {
		while (num.num < 10000) {
			System.out.println(num.num++);

		}
		num.flag = true;
	}
}

public class ThreadTest {

	public static void main(String[] args) throws Exception {

		// 利用多线程快速输出1-10000

		// 1.传统写法
		long t1 = System.nanoTime();
		for (int i = 0; i < 10000; i++) {
			System.out.println(i);
		}
		long t2 = System.nanoTime();
		System.out.println("花费时间：" + (t2 - t1));

		// 2.使用4线程同时输出
		Num num = new Num();
		Cout cout1 = new Cout(num);
		Cout cout2 = new Cout(num);
		Cout cout3 = new Cout(num);
		Cout cout4 = new Cout(num);

		long t3 = System.nanoTime();

		cout1.start();
		cout2.start();
		cout3.start();
		cout4.start();

		long t4 = System.nanoTime();

		while (!num.flag) {
			System.out.println("  传统花费时间：" + (t2 - t1));
			System.out.println("多线程花费时间：" + (t4 - t3));
		}

	}

}
